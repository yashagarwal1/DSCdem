param(
[Parameter(Mandatory)]
[String]$automationAccountName, #enter the automation account name

[Parameter(Mandatory)]
[String]$credentialName, #enter the credentail name as Admincreds

[Parameter(Mandatory)]
[String]$domainName, #enter the domain name for the domain controller

[Parameter(Mandatory)]
[System.Management.Automation.PSCredential] $Admincreds #UserName = user@domainName Password = password
)

#Login-AzureRmAccount

#checks if the automation account is present. returns an error if it is not. 
$automationAccount�= (Get-AzureRmAutomationAccount | Where-Object {$_.AutomationAccountName -eq�$automationAccountName})
if(!$automationAccount){
throw�"Automation Account�$automationAccountName�not found"
}

#get the resource groupname from the automation account details
$rgName = $automationAccount.ResourceGroupName

#import the xDSCDomainjoin module in the automation account
$moduleUrl = 'https://devopsgallerystorage.blob.core.windows.net/packages/xdscdomainjoin.1.1.0.nupkg' #URL for the xDSCDomainjoin module
$moduleName = 'xDSCDomainjoin'
New-AzureRmAutomationModule -ResourceGroupName $rgName -AutomationAccountName $automationAccountName -Name $moduleName -ContentLink $moduleUrl
Start-Sleep -Seconds 150

#Gets the path of the current directory to map the location of the DSC configurtion files. 
$path = Get-Location
Set-Location $path
$ConFile1 = "$path\DomainJoinConfiguration1.ps1" #path to the configuration file of DomainJoinConfiguration
$ConFile2 = "$path\InstallIIS.ps1" #path to the configuration file of IISInstall

#Create a credential in the autoamtion account for storing the values of the domain controller username and password. 
$Credential = $Credential = New-Object System.Management.Automation.PSCredential ($Admincreds.UserName, $Admincreds.Password)
New-AzureRmAutomationCredential -AutomationAccountName $automationAccountName -Name $credentialName -Value $Credential -ResourceGroupName $rgName

#Import and compile DSC configuration for DSCdomainjoin extension
Import-AzureRmAutomationDscConfiguration -AutomationAccountName $automationAccountName -ResourceGroupName $rgName -SourcePath $ConFile1  -Force -Published
$Parameters�=�@{
    "domain" = $domainName
����"Admincreds"�=�'Admincreds'
}
$CompilationJob1 = Start-AzureRmAutomationDscCompilationJob -ConfigurationName DomainJoinConfiguration1 -ResourceGroupName $rgName -AutomationAccountName $automationAccountName -Parameters $Parameters
Start-Sleep -Seconds 60

#Import and compile DSC configuration for IIS install extension
Import-AzureRmAutomationDscConfiguration -AutomationAccountName $automationAccountName -ResourceGroupName $rgName -SourcePath $ConFile2  -Force -Published
$CompilationJob2 = Start-AzureRmAutomationDscCompilationJob -ConfigurationName InstallIIS -ResourceGroupName $rgName -AutomationAccountName $automationAccountName
Start-Sleep -Seconds 60

#get the status of the DSC compilation jobs
Get-AzureRmAutomationDscCompilationJob -ResourceGroupName $rgName -AutomationAccountName $automationAccountName