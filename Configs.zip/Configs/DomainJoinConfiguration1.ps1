Configuration DomainJoinConfiguration1
{   
param
    (
	
   	[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

	[Parameter(Mandatory)]
	[String]$domain

    )

        Import-DscResource -ModuleName xDSCDomainjoin
      
    node localhost 
    {
        xDSCDomainjoin JoinDomain
        {
            Domain = $domain
            Credential = New-Object System.Management.Automation.PSCredential ($Admincreds.UserName, $Admincreds.Password)		
        }
    }
}